from selenium.webdriver.common.by import By

class menulocators:

    portfolio = (By.XPATH, "//*[@id='portfolio']")
    about = (By.XPATH, "//*[@id='about']")