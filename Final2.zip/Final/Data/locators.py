from selenium.webdriver.common.by import By

class menulocators:

    portfolio = (By.XPATH, "//*[@id='portfolios']")
    about = (By.XPATH, "//*[@id='abouts']")